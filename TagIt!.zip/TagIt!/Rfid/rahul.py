import serial
import urllib2
ser=serial.Serial('COM11','9600',timeout=0.5)
while  True:        
    response=ser.readline()
    if(response.startswith('#')):    
             print(response)
             t=response[1:]
             print(t)
             t1=t[:-2]
             print(t1)  

            #print(urllib2.urlopen('https://api.thingspeak.com/update?api_key=98HUXG8XHIKA6UTL&field1=0'+t1));
